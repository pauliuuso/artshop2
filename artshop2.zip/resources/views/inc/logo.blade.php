<a class="logo" href="/gallery">
</a>
