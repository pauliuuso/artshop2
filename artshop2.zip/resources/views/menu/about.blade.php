@extends("layouts/app")

@section("content")

<div class="row mt-7">
    <div class="col-12">

    </div>
</div>

@endsection