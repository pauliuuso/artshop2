<?php $__env->startSection("content"); ?>

<div class="row mt-7">
    <div class="col-12 mb-5">
        <h2>Manage artworks:</h2>
    </div>

    <div class="col-12 col-lg-6">
        <?php if(count($artworks) > 0): ?>

            <?php $__currentLoopData = $artworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artwork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row category bg-success mb-2">
                <div class="col-12">
                    <span class="text-uppercase"><?php echo e($artwork->title); ?></span> by <?php echo e($artwork->getAuthor->name); ?> <?php echo e($artwork->getAuthor->surname); ?>

                    <a href="/artwork/edit/<?php echo e($artwork->id); ?>">
                        <i class="fas fa-edit"></i>
                    </a>
                </div>
                <div class="col-12">
                    <img class="manage-image" src="/storage/artworks/<?php echo e($artwork->thumbnail_name); ?>">
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php else: ?>
                <p>Nothing found!</p>
        <?php endif; ?>
    </div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>