<?php $__env->startSection("content"); ?>

<div class="row mt-7">
    <div class="col-12 mb-2 mb-sm-5 main-title">
        <h1 class="marvel">ORDERS</h1>
    </div>


    <?php if(count($orders) > 0 && $orders != null): ?>

        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 mb-2 pt-2 pb-2 order">
                <p>Customer: <?php echo e($order->name); ?> <?php echo e($order->surname); ?> (<?php echo e($order->created_at); ?>)</p>
                <p>Address: <?php echo e($order->address); ?></p>
                <p>Payment id: <a href="https://dashboard.stripe.com/test/payments/<?php echo e($order->payment_id); ?>"><?php echo e($order->payment_id); ?></a></p>

                <?php $__currentLoopData = $order->cart->artworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artwork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="row mb-5">
                        <div class="col-6 col-xl-3">
                            <img class="img-fluid visibility-hidden" src="/storage/artworks/<?php echo e($artwork['artwork']->picture_name); ?>" onload="DisplayImage(this)"/>
                        </div>
                        <div class="col-6">
                            <p>Title: <?php echo e($artwork["artwork"]->title); ?></p>
                            <p>Quantity: <?php echo e($artwork["count"]); ?></p>
                            <p>Price: <?php echo e($artwork["price"]); ?> €</p>
                            <p>Size: <?php echo e($artwork["size"]); ?> cm</p>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <p>Total price: <?php echo e($order->cart->totalPrice); ?> €</p>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <?php echo e($orders->links()); ?>


    <?php else: ?>
        <div class="col-12">
            <p>Nothing found!</p>
        </div>
    <?php endif; ?>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>