<?php $__env->startSection("content"); ?>

<div class="row mt-7">

    <div class="col-12 text-center mb-5">
        <h2 class="text-uppercase">Edit artwork:</h2>
    </div>

    <div class="col-12 col-xl-6 mb-5">
        <?php echo Form::open(["action" => ["ArtworksController@update", $artwork->id], "method" => "POST", "files" => true]); ?>

        <div class="form-group">
            <?php echo e(Form::label("title", "Title:")); ?>

            <?php echo e(Form::text("title", $artwork->title, ["class" => "form-control", "placeholder" => ""])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("category", "Category:")); ?>

            <?php echo e(Form::select("category", $categories, $category, ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("author", "Author:")); ?>

            <?php echo e(Form::select("author", $authors, $author, ["class" => "form-control"])); ?>

        </div>
        <div class="row mb-3">
            <div class="col-12">
                <p>Sizes:</p> 
                <?php $__currentLoopData = $artwork->getSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="customization-select-option mr-1" href="/edit-size/<?php echo e($size->id); ?>">
                        <p><?php echo e($size->width); ?>x<?php echo e($size->height); ?></p>
                        <p><?php echo e($size->price); ?> €</p>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="/new-size/<?php echo e($artwork->id); ?>">
                    <i class="fas fa-plus fs-40 ml-2"></i>
                </a>
            </div>
        </div>
        <div class="form-group">
            <?php echo e(Form::label("description", "Description:")); ?>

            <?php echo e(Form::textarea("description", $artwork->description, ["class" => "form-control ckeditor"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("year", "Year:")); ?>

            <?php echo e(Form::number("year", $artwork->year, ["class" => "form-control", "placeholder" => ""])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("thumbnail", "Thumbnail:")); ?>

            <?php echo e(Form::file("thumbnail", ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("picture", "Picture:")); ?>

            <?php echo e(Form::file("picture", ["class" => "form-control"])); ?>

        </div>

        <?php echo e(Form::hidden("_method", "PUT")); ?>

        <?php echo e(Form::submit("Submit", ["class" => "artshop-button"])); ?>

        <?php echo Form::close(); ?>

    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>