<?php $__env->startSection("content"); ?>

<div class="row">

    <div class="col-12 col-md-6 col-lg-7 mt-9">
        <div class="row">
            <div class="col-12 col-lg-10 col-xl-9">
                <h4 class="text-uppercase main-title-sub">CHECKOUT</h4>
                <a class="text-underline" href="/get-cart">BACK TO SHOPPING CART</a>
                <p>Order id: <?php echo e(Session::get("cart")->orderId); ?></p>

                <div>
                    <?php if(Session::has("cart")): ?>
                    <?php echo Form::open(["action" => "ArtworksController@completecheckoutpaypal", "method" => "POST", "id" => "checkout-form", "novalidate" => "novalidate"]); ?>


                        <div class="checkout-2 mt-6">

                            <p>PAYMENT METHOD:</p>

                            <a href="/checkoutpayment/paypal">
                                <div class="payment-method mb-2 p-2 <?php echo e($type == 'paypal' ? 'active' : ''); ?>">
                                    PAYPAL
                                </div>
                            </a>

                            <a href="/checkoutpayment/transfer">
                                <div class="payment-method mb-2 p-2 <?php echo e($type == 'transfer' ? 'active' : ''); ?>">
                                    BANK TRANSFER
                                </div>
                            </a>

                            <a href="/checkoutpayment/credit">
                                <div class="payment-method mb-2 p-2 <?php echo e($type == 'credit' ? 'active' : ''); ?>">
                                    CREDIT CARD
                                </div>
                            </a>

                            <p class="mt-6">PayPal</p>
                            <p>Total: <?php echo e(Session::get('cart')->totalPrice + 4.99); ?></p>

                            <?php echo e(Form::hidden("price", Session::get('cart')->totalPrice)); ?>


                            <?php echo e(Form::hidden("payment_type", $type)); ?>


                            <div class="row mt-4 mb-5">
                                <div class="col-6 text-left pt-3">
                                    <a href="/checkoutaddress" class="artshop-button-a">BACK</a>
                                </div>
                                <div class="col-6 text-right">
                                    <?php echo e(Form::submit("PURCHASE", ["class" => "artshop-button mb-2", "id" => "checkout-button"])); ?>

                                    <p class="text-small">YOU WILL BE REDIRECTED TO PAYPAL</p>
                                </div>
                            </div>

                        </div>
                    
                        <p id="charge-error" class="text-danger <?php echo e(!Session::has('error') ? 'hidden' : ''); ?>">
                            <?php echo e(Session::get("error")); ?>

                        </p>
            
                    <?php echo Form::close(); ?>

                    <?php else: ?>
                    <div class="col-12">
                        <p>Your chart is empty!</p>
                    </div>
                    <?php endif; ?>
                </div>
                
            </div>
        </div>
    </div>

    <?php echo $__env->make("inc/checkoutright", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/checkout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>