<?php $__env->startSection('content'); ?>
<div class="row mt-7">

        <div class="col-12 mb-5">
            <h2 class="text-uppercase">Edit user <?php echo e($user->email); ?>:</h2>
        </div>
    
        <div class="col-12 col-xl-6 mb-5">
            <form class="form-horizontal" method="POST" action="/users/update/<?php echo e($user->id); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                    <label for="name" >Name:</label>
                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required>
                </div>

                <div class="form-group <?php echo e($errors->has('surname') ? 'has-error' : ''); ?>">
                    <label for="surname" >Surname:</label>
                    <input id="surname" type="text" class="form-control" name="surname" value="<?php echo e($user->surname); ?>" required>
                </div>

                <div class="form-group">
                    <label for="description" >Description:</label>
                    <textarea id="description" class="form-control ckeditor" name="description"><?php echo e($user->description); ?></textarea>
                </div>

                <div class="form-group <?php echo e($errors->has('role') ? 'has-error' : ''); ?>">
                    <label for="role" >Role:</label>
                    <select name="role" class="form-control">
                        <option value="user" <?php if($user->role == "user"): ?> selected <?php endif; ?>>User</option>
                        <option value="author" <?php if($user->role == "author"): ?> selected <?php endif; ?>>Author</option>
                    </select>
                </div>

                <div class="form-group <?php echo e($errors->has('active') ? 'has-error' : ''); ?>">
                    <label for="active" >Active:</label>
                    <select name="active" class="form-control">
                        <option value="0" <?php if($user->active == 0): ?> selected <?php endif; ?>>No</option>
                        <option value="1" <?php if($user->active == 1): ?> selected <?php endif; ?>>Yes</option>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        Update
                    </button>
                </div>
            </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>