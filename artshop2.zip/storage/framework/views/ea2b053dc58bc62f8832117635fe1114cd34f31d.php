<?php $__env->startSection("content"); ?>

<div class="row mt-3 mt-7">
    <div class="col-12 mb-2 mb-sm-5 main-title">
        <h1 class="marvel">GALLERY</h1>
    </div>

    <div class="col-12 sort d-none d-sm-block">
        <div class="row">
            <div class="col-12 mb-2">
                <div class="sort-option">SORT BY:</div>
                <a href="/" class="sort-option">
                    <div <?php if($filter == ""): ?> class="text-underline" <?php endif; ?>>ALL</div>
                </a>
                <a class="sort-option" onclick="ToogleOptionDesktop('category-list-desktop')">
                    <div <?php if($filter == "kind"): ?> class="text-underline" <?php endif; ?>>KIND</div>
                </a>
                <a class="sort-option" onclick="ToogleOptionDesktop('author-list-desktop')">
                    <div <?php if($filter == "artist"): ?> class="text-underline" <?php endif; ?>>ARTIST</div>
                </a>
                <a class="sort-option" onclick="ToogleOptionDesktop('year-list-desktop')">
                    <div <?php if($filter == "year"): ?> class="text-underline" <?php endif; ?>>YEAR</div>
                </a>
            </div>
        </div>
    </div>
    
    <div class="col-12 mb-5 sort d-none d-sm-block">
        <?php if($categories != null): ?>
            <span class="category-list-desktop desktop-sort-option animated d-none">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/gallery/kind/<?php echo e($category->id); ?>" class="sort-option-secondary">
                        <div class="text-uppercase <?php if($category->id == $sortId): ?> text-underline <?php endif; ?>"><p><?php echo e($category->name); ?></p></div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </span>
        <?php endif; ?>

        <?php if($authors != null): ?>
            <span class="author-list-desktop desktop-sort-option animated d-none">
                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/gallery/artist/<?php echo e($author->id); ?>" class="sort-option-secondary">
                        <div class="text-uppercase <?php if($author->id == $sortId): ?> text-underline <?php endif; ?>"><p><?php echo e($author->name); ?> <?php echo e($author->surname); ?></p></div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </span>
        <?php endif; ?>

        <span class="year-list-desktop desktop-sort-option animated d-none">
            <a href="#" class="sort-option-secondary">
                <div><p>Year</p></div>
            </a>
        </span>
    </div>

    <div class="col-12 mt-3 mb-2 mobile-sort d-sm-none">
        <div class="text-center title pointer mb-4" onclick="ToogleSort()">
            <p class="mb-1 scroll-down animated">SORT ITEMS</p>
            <i class="fas fa-chevron-down pointer scroll-down animated"></i>
            <i class="fas fa-chevron-up pointer d-none scroll-up animated"></i>
        </div>
        <div id="mobile-sort-links" class="pl-5">

            <div class="mobile-links-area">
                <a href="/" class="sort-option title">
                    <div <?php if($filter == ""): ?> class="text-underline title" <?php endif; ?>>ALL</div>
                </a>

                <a class="sort-option title" onclick="ToogleOptions(this)">
                    <div <?php if($filter == "kind"): ?> class="text-underline title pointer" <?php endif; ?>>KIND</div>
                </a>
                <div class="option-list ml-4">

                    <?php if($categories != null): ?>
                        <span>

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/gallery/kind/<?php echo e($category->id); ?>" class="sort-option-secondary">
                                <div class="text-uppercase <?php if($category->id == $sortId): ?> text-underline <?php endif; ?>"><p class="m-0"><?php echo e($category->name); ?></p></div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </span>
                    <?php endif; ?>

                </div>

                <a class="sort-option title" onclick="ToogleOptions(this)">
                    <div <?php if($filter == "artist"): ?> class="text-underline title" <?php endif; ?>>ARTIST</div>
                </a>

                <div class="option-list ml-4">
                    <?php if($authors != null): ?>
                        <span>

                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/gallery/artist/<?php echo e($author->id); ?>" class="sort-option-secondary">
                                <div class="text-uppercase <?php if($author->id == $sortId): ?> text-underline <?php endif; ?>"><p><?php echo e($author->name); ?> <?php echo e($author->surname); ?></p></div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </span>
                    <?php endif; ?>
                </div>

                <div class="sort-option title">YEAR</div>
            </div>

        </div>
    </div>

    <?php if(count($artworks) > 0 && $artworks != null): ?>
        <div class="col-12 artwork-list">
            <div class="row">
                <?php $__currentLoopData = $artworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artwork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="col-10 col-sm-6 col-lg-3 offset-1 offset-sm-0 art-link" href="/artwork/show/<?php echo e($artwork->id); ?>">
                        <div class="art-wrapper">
                            <img src="/storage/artworks/<?php echo e($artwork->thumbnail_name); ?>" class="art-image visibility-hidden" onload="ImageLoaded(this)"/>
                        </div>
                        <div class="art-info pt-4 text-center mb-5">
                            <h3 class="text-uppercase"><?php echo e($artwork->title); ?></h3>
                            <p class="text-uppercase"><?php echo e($artwork->getAuthor->name . " " . $artwork->getAuthor->surname); ?></p>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="col-12 text-center">
            <?php echo e($artworks->links()); ?>

        </div>

    <?php else: ?>
        <div class="col-12">
            <p>Nothing found!</p>
        </div>
    <?php endif; ?>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>