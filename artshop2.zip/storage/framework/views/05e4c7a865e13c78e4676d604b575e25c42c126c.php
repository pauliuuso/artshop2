<?php $__env->startSection("content"); ?>

<div class="row mt-7">

    <div class="col-12 mb-2 mb-sm-5 main-title">
        <h1 class="marvel">ADD BACKGROUND</h1>
    </div>

    <div class="col-12 col-xl-6 mb-5">
        <?php echo Form::open(["action" => "BackgroundsController@store", "method" => "POST", "files" => true]); ?>

        <div class="form-group">
            <?php echo e(Form::label("title", "Title:")); ?>

            <?php echo e(Form::text("title", "", ["class" => "form-control", "placeholder" => ""])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("width", "Assumed width (cm):")); ?>

            <?php echo e(Form::text("width", "", ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("height", "Assumed height (cm):")); ?>

            <?php echo e(Form::text("height", "", ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("picture", "Picture:")); ?>

            <?php echo e(Form::file("picture", ["class" => "form-control"])); ?>

        </div>
        <?php echo e(Form::submit("Submit", ["class" => "artshop-button mt-5"])); ?>

        <?php echo Form::close(); ?>

    </div>

    <div class="clearfix"></div>

    <div class="col-12">
        <div class="row">
            <?php if(count($backgrounds) > 0 && $backgrounds != null): ?>

            <?php $__currentLoopData = $backgrounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $background): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="col-12 col-xl-6 art-link" href="/backgrounds/edit/<?php echo e($background->id); ?>">
                    <i class="fas fa-edit background-edit-button"></i>
                    <div class="background-wrapper">
                        <img src="/storage/backgrounds/<?php echo e($background->background_name); ?>" class="p-0 m-0 background-image visibility-hidden" onload="WrappedImageLoaded(this)"/>
                    </div>
                    <div class="art-info pt-4 text-center mb-5">
                        <h3 class="text-uppercase"><?php echo e($background->title); ?></h3>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>
            <div class="col-12">
                <p>Nothing found!</p>
            </div>
            <?php endif; ?>
        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>