<?php $__env->startSection('content'); ?>
<div class="row mt-7">

    <div class="col-12 mb-2 mb-sm-5 main-title">
        <h1 class="marvel">RESET PASSWORD</h1>
    </div>

    <div class="col-12 mb-5 text-center">

        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <form class="form-horizontal" method="POST" action="/password/email">
            <?php echo e(csrf_field()); ?>


            <div class="form-group col-xl-6 offset-xl-3 <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <!-- <label for="email">Email address:</label> -->
                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email address" required>
            </div>

            <div class="form-group">
                <button type="submit" class="artshop-button mt-5">
                    Send Password Reset Link
                </button>
            </div>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>