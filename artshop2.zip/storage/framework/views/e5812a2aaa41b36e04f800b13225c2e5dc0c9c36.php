<?php $__env->startSection("content"); ?>

<div class="row mt-7">
    <div class="col-12 mb-2 mb-sm-5 main-title">
        <h1 class="marvel">CATEGORIES</h1>
    </div>

    <div class="col-12 col-lg-6">

        <?php echo Form::open(["action" => "CategoriesController@store", "method" => "POST", "class" => "mb-5"]); ?>

            <div class="form-group">
                <?php echo e(Form::label("name", "Category name:")); ?>

                <?php echo e(Form::text("name", "", ["class" => "form-control", "placeholder" => ""])); ?>

            </div>
        <?php echo e(Form::submit("Submit", ["class" => "artshop-button mt-5"])); ?>

        <?php echo Form::close(); ?>



        <?php if(count($categories) > 0): ?>

        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="category bg-success mb-2">
                <?php echo e($category->name); ?>

                <a href="/category/edit/<?php echo e($category->id); ?>">
                    <i class="fas fa-edit"></i>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        <?php else: ?>
            <p>Nothing found!</p>
        <?php endif; ?>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>