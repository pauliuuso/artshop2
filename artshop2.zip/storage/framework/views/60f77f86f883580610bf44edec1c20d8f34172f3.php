<?php $__env->startSection("content"); ?>

<div class="row mt-5">

    <div class="col-12 text-center mb-5">
        <h2 class="text-uppercase">Add new size:</h2>
    </div>

    <div class="col-12 col-xl-6 mb-5">
        <?php echo Form::open(["action" => "ArtworksController@addsize", "method" => "POST"]); ?>

        <div class="form-group">
            <?php echo e(Form::label("width", "Width (cm):")); ?>

            <?php echo e(Form::text("width", "", ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("height", "Weight (cm):")); ?>

            <?php echo e(Form::text("height", "", ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("price", "Price:")); ?>

            <?php echo e(Form::number("price", "", ["class" => "form-control", "placeholder" => ""])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("background", "Background:")); ?>

            <?php echo e(Form::select("background", $backgroundIdsAndTitles, $selectedBackground, ["class" => "form-control", "id" => "background-selector", "placeholder" => "Select Background"])); ?>

        </div>
        <div class="row mb-4" id="background-list" >
            <?php $__currentLoopData = $backgrounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $background): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="background-<?php echo e($background->id); ?>" class="col-12 background">
                    <img class="img-fluid" src="/storage/backgrounds/<?php echo e($background->background_name); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e(Form::submit("Submit", ["class" => "btn btn-primary"])); ?>

        <?php echo Form::close(); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>