<?php $__env->startSection('content'); ?>
<div class="row mt-7">

        <div class="col-12 mb-2 mb-sm-5 main-title">
            <h1 class="marvel">REGISTER</h1>
        </div>
    
        <div class="col-12 mb-5 text-center">
            <form class="form-horizontal" method="POST" action="/register">
                <?php echo e(csrf_field()); ?>


                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                    <!-- <label for="name" >Name:</label> -->
                    <input id="name" type="text" class="form-control col-12 col-xl-6 offset-xl-3" name="name" value="<?php echo e(old('name')); ?>" required placeholder="Name" autofocus>
                </div>

                <div class="form-group <?php echo e($errors->has('surname') ? 'has-error' : ''); ?>">
                    <!-- <label for="surname" >Surname:</label> -->
                    <input id="surname" type="text" class="form-control col-12 col-xl-6 offset-xl-3" name="surname" value="<?php echo e(old('surname')); ?>" required placeholder="Surname" autofocus>
                </div>

                <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                    <!-- <label for="email">Email Address:</label> -->
                    <input id="email" type="email" class="form-control col-12 col-xl-6 offset-xl-3" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email address" required>
                </div>

                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <!-- <label for="password">Password:</label> -->
                    <input id="password" type="password" class="form-control col-12 col-xl-6 offset-xl-3" name="password" placeholder="Password" required>
                </div>

                <div class="form-group">
                    <!-- <label for="password-confirm" class="col-md-4 control-label">Confirm password:</label> -->
                    <input id="password-confirm" type="password" class="form-control col-12 col-xl-6 offset-xl-3" name="password_confirmation" placeholder="Confirm password" required>
                </div>

                <div class="form-group">
                    <button type="submit" class="artshop-button mt-5">
                        Register
                    </button>
                </div>
            </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>