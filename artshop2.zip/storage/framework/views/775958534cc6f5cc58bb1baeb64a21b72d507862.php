<?php $__env->startSection("content"); ?>

<div class="row cart-wrapper mt-7">

    <div class="col-12">
        <!-- <a class="float-right btn btn-danger <?php echo e(!Session::has('cart') ? 'visibility-hidden' : ''); ?>" href="/remove-all-from-cart">Clear all</a> -->
        <h4 class="main-title-sub cart">SHOPPING CART&nbsp;&nbsp;</h4>
        <h4 class="main-title-sub total">TOTAL: <?php echo e(Session::has("cart") ? $totalCount : '0'); ?></h4>
    </div>

    <div class="col-12 mb-5">
        <a href="/"><p class="text-underline">BACK TO SHOP</p></a>
    </div>

    <div class="col-12 d-none d-md-block">
        <div class="row">
            <div class="col-12 col-md-6 cart-orders-item">
                <p>ITEM</p>
            </div>

            <div class="col-12 col-md-2 cart-orders-item">
                <p>YOUR OPTIONS</p>
            </div>

            <div class="col-12 col-md-2 cart-orders-item text-right">
                <p>QUANTITY</p>
            </div>

            <div class="col-12 col-md-2 cart-orders-item text-right">
                <p>ITEM PRICE</p>
            </div>
        </div>
    </div>

    <div class="col-12">
        <div class="col-12 cart-orders-underline mb-3"></div>
    </div>

    <?php if(Session::has("cart")): ?>

        <?php $__currentLoopData = $artworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $artwork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12">
                <div class="row">

                    <div class="col-12 col-md-6 cart-item-first">
                        <div class="size-half mt-2 mb-2">
                            <img id="artwork-image" class="visibility-hidden size-full" src="/storage/artworks/<?php echo e($artwork['artwork']->picture_name); ?>" onload="DisplayImage(this)"/>
                        </div>
                        <div class="size-half pl-4 mt-2">
                            <p><?php echo e($artwork["artwork"]->getAuthor->name); ?> <?php echo e($artwork["artwork"]->getAuthor->surname); ?></p>
                            <p><?php echo e($artwork["artwork"]->title); ?>, <?php echo e($artwork["artwork"]->year); ?></p>
                        </div>
                    </div>

                    <div class="col-12 col-md-2">
                        <p>Paper: Quality paper</p>
                        <p>Frame: No frame</p>
                        <p>Size: <?php echo e($artwork["size"]); ?></p>
                    </div>

                    <div class="col-12 col-md-2 text-right">
                        <p><span class="d-md-none">Count: </span> <?php echo e($artwork["count"]); ?></p>
                    </div>

                    <div class="col-12 col-md-2 text-right">
                        <p><span class="d-md-none">Price: </span> <?php echo e($artwork["price"]); ?> €</p>
                    </div>

                </div>
            </div>
            <div class="col-12 mb-4">
                <a href="/remove-from-cart/<?php echo e($index); ?>">
                    <p class="text-underline text-right">Delete</p>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php else: ?>
        <div class="col-12">
            <p>Your chart is empty!</p>
        </div>
    <?php endif; ?>

    <div class="col-12">
        <div class="col-12 cart-orders-underline mb-3"></div>
    </div>

    <div class="col-12 text-right mb-5">
        <p>TOTAL PRICE: <?php echo e(Session::has("cart") ? $totalPrice : '0'); ?> €</p>
        <a class="customization-select-option-low" href="/checkout"><p class="p-0 m-0">CHECKOUT</p></a>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>