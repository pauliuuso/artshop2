<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/animate.css_3.5.2.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/slick.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/slick-theme.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

        <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/tether_1.4.0.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap_4.0.0-alpha.6.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/fontawesome_v5.0.6.js')); ?>"></script>
        <script type="text/javascript" src="https://js.stripe.com/v2/"></script>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <title><?php echo e(config("app.name", "Artshop")); ?></title>
    </head>
    <body>
        <div class="container-fluid">
            <div class="row">
                <div class="hidden-lg-down col-xl-1">
                </div>
                <div class="col-12 col-xl-10">
                    <?php echo $__env->make("inc/logo", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make("inc/menu", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make("inc/menutables", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make("inc/errors", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="content">
                        <?php echo $__env->yieldContent("content"); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="curtain">

        </div>

    <!-- Scripts -->
    <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script>
        if($(".ckeditor").length)
        {
            CKEDITOR.replaceClass = 'ckeditor';
        }
    </script>

    </body>
</html>