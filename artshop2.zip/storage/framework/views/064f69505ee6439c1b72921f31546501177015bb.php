<?php $__env->startSection("content"); ?>

<div class="row mt-7">

    <div class="col-12 mb-2 mb-sm-5 main-title">
        <h1 class="marvel">ADD NEW</h1>
    </div>
    
    <div class="col-12 col-xl-6 mb-5">
        <?php echo Form::open(["action" => "ArtworksController@store", "method" => "POST", "files" => true]); ?>

        <div class="form-group">
            <?php echo e(Form::label("title", "Title:")); ?>

            <?php echo e(Form::text("title", "", ["class" => "form-control", "placeholder" => ""])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("category", "Category:")); ?>

            <?php echo e(Form::select("category", $categories, null, ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("author", "Author:")); ?>

            <?php echo e(Form::select("author", $authors, null, ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("description", "Description:")); ?>

            <?php echo e(Form::textarea("description", "", ["class" => "form-control ckeditor"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("width", "Width (cm):")); ?>

            <?php echo e(Form::text("width", "", ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("height", "Height (cm):")); ?>

            <?php echo e(Form::text("height", "", ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("year", "Year:")); ?>

            <?php echo e(Form::number("year", "", ["class" => "form-control", "placeholder" => ""])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("price", "Price:")); ?>

            <?php echo e(Form::number("price", "", ["class" => "form-control", "placeholder" => ""])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("thumbnail", "Thumbnail:")); ?>

            <?php echo e(Form::file("thumbnail", ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("picture", "Picture:")); ?>

            <?php echo e(Form::file("picture", ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("background", "Background:")); ?>

            <?php echo e(Form::select("background", $backgroundIdsAndTitles, "", ["class" => "form-control", "id" => "background-selector", "placeholder" => "Select Background"])); ?>

        </div>
        <div class="row mb-4" id="background-list" >
            <?php $__currentLoopData = $backgrounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $background): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="background-<?php echo e($background->id); ?>" class="col-12 background">
                    <img class="img-fluid" src="/storage/backgrounds/<?php echo e($background->background_name); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e(Form::submit("Submit", ["class" => "artshop-button"])); ?>

        <?php echo Form::close(); ?>

    </div>

</div>

<script type="text/javascript">
    ShowSelectedBackground();
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>