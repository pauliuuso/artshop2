<?php $__env->startSection("content"); ?>

<div class="row mt-7">
    <div class="col-12 mb-2 mb-sm-5 main-title">
        <h1 class="marvel">EDIT CATEGORY</h1>
    </div>

    <div class="col-12 col-lg-6">

        <?php echo Form::open(["action" => ["CategoriesController@update", $category->id], "method" => "POST", "class" => "mb-1"]); ?>

            <div class="form-group">
                <?php echo e(Form::label("name", "Category name:")); ?>

                <?php echo e(Form::text("name", $category->name, ["class" => "form-control", "placeholder" => ""])); ?>

            </div>
            <?php echo e(Form::hidden("_method", "PUT")); ?>

            <?php echo e(Form::submit("Submit", ["class" => "artshop-button mt-5"])); ?>

        <?php echo Form::close(); ?>


        <?php echo Form::open(["action" => ["CategoriesController@destroy", $category->id], "method" => "POST"]); ?>

            <?php echo e(Form::hidden("_method", "DELETE")); ?>

            <?php echo e(Form::submit("Delete", ["class" => "artshop-button red"])); ?>

        <?php echo Form::close(); ?>


    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>