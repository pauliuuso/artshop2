<?php $__env->startSection("content"); ?>

<div class="row mt-7 mb-5">

    <div class="col-12">
        <?php if(!Auth::guest() && Auth::user()->role == "admin"): ?>
            <?php echo Form::open(["action" => ["ArtworksController@destroy", $artwork->id], "method" => "POST"]); ?>

                <a href="/artwork/edit/<?php echo e($artwork->id); ?>" class="artshop-button-a">Edit</a>
                <?php echo e(Form::hidden("_method", "DELETE")); ?>

                <?php echo e(Form::submit("Delete", ["class" => "artshop-button red"])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    </div>

    <div class="col-12 main-title">
        <h1 class="marvel text-uppercase"><?php echo e($artwork->title); ?></h1>
        <h4 class="text-uppercase main-title-sub">BY <?php echo e($artwork->getAuthor->name); ?> <?php echo e($artwork->getAuthor->surname); ?></h4>
    </div>

    <div class="col-12 col-md-6 mb-4 order-10">
        <div class="row">

            <div class="col-12 mb-4">
                <img class="col-12 p-0 visibility-hidden" src="/storage/artworks/<?php echo e($artwork->picture_name); ?>" onload="ImageLoaded(this); ShowDescription(this);"/>
            </div>

        </div>
    </div>


    <div class="col-12 col-md-6 text-justify order-12 order-md-11">

        <div class="artwork-description visibility-hidden pr-2">
            <p class="text-uppercase text-underline">DESCRIPTION</p>
            <?php echo $artwork->description; ?>

    
            <div class="row mt-2">
                <div class="col-12 text-justify">
                    <p class="text-uppercase text-underline">AUTHOR BIO</p>
                    <p><?php echo $artwork->getAuthor->description; ?></p>
                </div>
            </div>
        </div>

        <div class="artwork-scrollbar-wrapper"></div>

        <div class="artwork-scroller visibility-hidden text-center">Scroll down for more info</div>

    </div>

    <div class="col-12 col-md-6 order-11 order-md-12">
        <div class="row">

        </div>
    </div>

</div>

<div class="row mb-5">
    <div class="col-12 mb-5">
        <h2 class="text-uppercase">PURCHASE</h2>
        <div class="col-12 purchase-beam"></div>
    </div>

    <div class="col-12 col-md-6 mb-5">
        <div class="artwork-image-wrapper">
            <img id="artwork-image" class="col-12 p-0 visibility-hidden animated" src="/storage/artworks/<?php echo e($artwork->getSizes[0]->preview_name); ?>" onload="ArtworkPreviewLoaded(this)"/>
        </div>
    </div>

    <div class="col-12 col-md-6 mb-5">

        <div class="mb-5">
            <p class="text-underline">CUSTOMIZING OPTIONS</p>
            <p>You can choose frame, material and print size.</p>
        </div>

        <div class="customization-option">PRINT SIZE:</div>
        <div class="mb-5">
            <?php $__currentLoopData = $artwork->getSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="customization-select-option <?php echo e(($index == 0) ? 'artwork-selected-option' : ''); ?>" onclick="SelectArtworkSize('<?php echo e($size->width); ?> x <?php echo e($size->height); ?>', this, <?php echo e($size->id); ?>); SelectPreview('<?php echo e($size->preview_name); ?>', this);"><p class="p-0 m-0"><?php echo e($size->width); ?> x <?php echo e($size->height); ?></p></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="customization-option">MATERIAL:</div>
        <div class="mb-5">
            <a class="customization-select-option artwork-selected-option" onclick="SelectPaperMaterial('QUALITY PAPER', this)"><p class="p-0 m-0">QUALITY PAPER</p></a>
            <a class="customization-select-option" onclick="SelectPaperMaterial('FOAM BOARD', this)"><p class="p-0 m-0">FOAM BOARD</p></a>
        </div>

        <div class="customization-option">Frame:</div>
        <div class="mb-5">
            <a class="customization-select-option artwork-selected-option" onclick="SelectFrame('NO FRAME', this)"><p class="p-0 m-0">NO FRAME</p></a>
            <a class="customization-select-option" onclick="SelectFrame('FRAME', this)"><p class="p-0 m-0">FRAME</p></a>
        </div>

        <div class="customization-option">Quantity:</div>
        <div class="mb-5">
            <div class="customization-select-option">
                <input id="quantity-input" type="text" value="1">
                <a class="fas fa-plus ml-2 pointer" href="#" onclick="QuantityAdd(1)"></a>
                <p id="quantity-error" class="text-danger p-0 m-0"></p>
            </div>
        </div>

        <div class="mb-5">
            <p class="text-underline">SUMMARY</p>
            <p>NAME: <span><?php echo e($artwork->title); ?></span></p>
            <p>SIZE: <span id="selected-artwork-size"><?php echo e($artwork->getSizes[0]->width); ?> x <?php echo e($artwork->getSizes[0]->height); ?></span></p>
            <p>MATERIAL: <span id="selected-material">QUALITY PAPER</span></p>
            <p>FRAME: <span id="frame">NO FRAME</span></p>
            <p>QUANTITY: <span id="quantity">1</span></p>
            <p>TOTAL PRICE: <span id="total-price"></span> €</p>
        </div>
        
        <form class="form-horizontal" method="GET" action="/add-to-cart">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" id="_token" name="_token" />
            <input type="hidden" value="<?php echo e($artwork->getSizes[0]->id); ?>" id="artwork-size" name="artwork-size" />
            <input type="hidden" value="<?php echo e($artwork->id); ?>" id="artwork-id" name="artwork-id" />
            <input type="hidden" value="NO FRAME" id="frame" name="frame" />
            <input type="hidden" value="1" id="count" name="count" />

            <button type="submit" class="customization-select-option-low">ADD TO CART</button>
        </form>

    </div>
</div>

<script>
    
    GetArtworkPrice();

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>