<?php $__env->startSection("content"); ?>

<div class="row mt-7">
    <div class="col-12 mb-5">
        <h2>Users:</h2>
    </div>

    <div class="col-12 col-lg-6">

        <?php if(count($users) > 0): ?>

        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="category bg-success mb-2">
                <?php echo e($user->name); ?> <?php echo e($user->surname); ?>

                <a href="/users/edit/<?php echo e($user->id); ?>">
                    <i class="fas fa-edit"></i>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        <?php else: ?>
            <p>Nothing found!</p>
        <?php endif; ?>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>