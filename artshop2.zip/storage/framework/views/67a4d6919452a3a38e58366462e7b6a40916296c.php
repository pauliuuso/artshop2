<?php $__env->startSection("content"); ?>

<div class="row mt-7">

    <div class="col-12">
        <?php if(!Auth::guest() && Auth::user()->role == "admin"): ?>
            <?php echo Form::open(["action" => ["BackgroundsController@destroy", $background->id], "method" => "POST"]); ?>

                <?php echo e(Form::hidden("_method", "DELETE")); ?>

                <?php echo e(Form::submit("Delete", ["class" => "artshop-button red"])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    </div>

    <div class="col-12 text-center mb-5">
        <h2 class="text-uppercase">Edit background:</h2>
    </div>

    <div class="col-12 mb-5">
        <img src="/storage/backgrounds/<?php echo e($background->background_name); ?>" class="p-0 m-0 img-fluid"/>
    </div>

    <div class="col-12 col-xl-6 mb-5">
        <?php echo Form::open(["action" => ["BackgroundsController@update", $background->id], "method" => "POST", "files" => true]); ?>

        <div class="form-group">
            <?php echo e(Form::label("title", "Title:")); ?>

            <?php echo e(Form::text("title", $background->title, ["class" => "form-control", "placeholder" => ""])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("width", "Width (cm):")); ?>

            <?php echo e(Form::text("width", "$background->width", ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("height", "Height (cm):")); ?>

            <?php echo e(Form::text("height", "$background->height", ["class" => "form-control"])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label("picture", "Picture:")); ?>

            <?php echo e(Form::file("picture", ["class" => "form-control"])); ?>

        </div>
        <?php echo e(Form::hidden("_method", "PUT")); ?>

        <?php echo e(Form::submit("Submit", ["class" => "artshop-button mt-5"])); ?>

        <?php echo Form::close(); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>