<?php $__env->startSection("content"); ?>

<div class="row">

    <div class="col-12 col-md-6 col-lg-7 mt-9">
        <div class="row">
            <div class="col-12 col-lg-10 col-xl-9">
                <h4 class="text-uppercase main-title-sub">CHECKOUT</h4>
                <a class="text-underline" href="/get-cart">BACK TO SHOPPING CART</a>

                <div>
                    <?php if(Session::has("cart")): ?>
                        <?php echo Form::open(["action" => "ArtworksController@postcheckoutaddress", "method" => "POST", "id" => "checkout-form"]); ?>

                
                        <div class="checkout-1 mt-6">
                            <p>CONTACT INFORMATION:</p>
                            <div class="form-group">
                                <?php echo e(Form::text("name", $order->name, ["class" => "form-control", "placeholder" => "Name"])); ?>

                            </div>
                    
                            <div class="form-group">
                                <?php echo e(Form::text("surname", $order->surname, ["class" => "form-control", "placeholder" => "Surname"])); ?>

                            </div>
    
                            <div class="form-group">
                                <?php echo e(Form::email("email", $order->email, ["class" => "form-control", "placeholder" => "Email"])); ?>

                            </div>
                    
                            <p class="mt-6">SHIPPING ADDRESS:</p>
                            <div class="form-group">
                                <?php echo e(Form::text("name_shipping", $order->name_shipping, ["class" => "form-control", "placeholder" => "Name"])); ?>

                            </div>
                    
                            <div class="form-group">
                                <?php echo e(Form::text("surname_shipping", $order->surname_shipping, ["class" => "form-control", "placeholder" => "Surname"])); ?>

                            </div>
    
                            <div class="row">
                                <div class="form-group col-12 col-sm-8">
                                    <?php echo e(Form::text("address", $order->address, ["class" => "form-control", "placeholder" => "Address"])); ?>

                                </div>
        
                                <div class="form-group col-12 col-sm-4">
                                    <?php echo e(Form::text("apartment", $order->apartment, ["class" => "form-control", "placeholder" => "Apartment / Suite"])); ?>

                                </div>

                                <div class="form-group col-12 col-sm-8">
                                    <?php echo e(Form::select("country", $countries, $order->country, ["class" => "col-12"])); ?>

                                </div>

                                <div class="form-group col-12 col-sm-4">
                                    <?php echo e(Form::text("postal_code", $order->postal_code, ["class" => "form-control", "placeholder" => "Postal code"])); ?>

                                </div>
                            </div>
    
                            <div class="form-group">
                                <?php echo e(Form::text("phone", $order->phone, ["class" => "form-control", "placeholder" => "Phone"])); ?>

                            </div>
    
                            <p class="m-0">SAVE THIS INFORMATION FOR THE NEXT TIME <input type="checkbox" id="save_info" class="m-0 ml-2 mb-3"></p>
                            <a class="text-underline" href="/get-cart">BACK TO SHOPPING CART</a>
    
                            <div class="row mt-4 mb-5">
                                <div class="col-12 text-right">
                                    <?php echo e(Form::submit("Continue", ["class" => "artshop-button", "id" => "checkout-button"])); ?>

                                </div>
                            </div>

                        </div>

                        <?php echo Form::close(); ?>

                        <?php else: ?>
                        <div class="col-12">
                            <p>Your chart is empty!</p>
                        </div>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make("inc/checkoutright", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/checkout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>