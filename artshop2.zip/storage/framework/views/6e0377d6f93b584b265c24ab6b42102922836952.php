<?php $__env->startSection("content"); ?>

<div class="row mt-7">
    <div class="col-12 mb-5">
        <h2>Checkout:</h2>
        <h4>Total count <?php echo e($totalPrice); ?> €</h4>
    </div>

    <?php if(Session::has("cart")): ?>
    <div class="col-12 col-md-6">
        <?php echo Form::open(["action" => "ArtworksController@checkout", "method" => "POST", "id" => "checkout-form", "onsubmit" => "event.preventDefault();"]); ?>


        <div class="form-group">
            <?php echo e(Form::label("name", "Name:")); ?>

            <?php echo e(Form::text("name", "", ["class" => "form-control", "placeholder" => "", "required" => true])); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::label("surname", "Surname:")); ?>

            <?php echo e(Form::text("surname", "", ["class" => "form-control", "placeholder" => "", "required" => true])); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::label("address", "Address:")); ?>

            <?php echo e(Form::text("address", "", ["class" => "form-control", "placeholder" => "", "required" => true])); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::label("card-number", "Credit card number:")); ?>

            <?php echo e(Form::text("card-number", "", ["class" => "form-control", "placeholder" => "", "required" => true])); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::label("card-expiry-month", "Card expiration month:")); ?>

            <?php echo e(Form::text("card-expiry-month", "", ["class" => "form-control", "placeholder" => "", "required" => true])); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::label("card-expiry-year", "Card expiration year:")); ?>

            <?php echo e(Form::text("card-expiry-year", "", ["class" => "form-control", "placeholder" => "", "required" => true])); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::label("card-cvc", "CVC:")); ?>

            <?php echo e(Form::text("card-cvc", "", ["class" => "form-control", "placeholder" => "", "required" => true])); ?>

        </div>

        <?php echo e(Form::submit("Buy now", ["class" => "btn btn-primary", "id" => "checkout-button"])); ?>


        <p id="charge-error" class="text-danger <?php echo e(!Session::has('error') ? 'hidden' : ''); ?>">
            <?php echo e(Session::get("error")); ?>

        </p>

        <?php echo Form::close(); ?>

    </div>
    <?php else: ?>
    <div class="col-12">
        <p>Your chart is empty!</p>
    </div>
    <?php endif; ?>


</div>

<script>

    Stripe.setPublishableKey('pk_test_E3REl5rEcxp7FJePFQkyyjpA');

    var $form = $("#checkout-form");

    $form.submit(function(event)
    {

        $("#charge-error").addClass("hidden");
        $("#checkout-button").prop("disabled", true);

        Stripe.card.createToken
        ({
            number: $('#card-number').val(),
            cvc: $('#card-cvc').val(),
            exp_month: $('#card-expiry-month').val(),
            exp_year: $('#card-expiry-year').val(),
            name: $('#name').val()
        }, stripeResponseHandler);

        return false;
    });

    function stripeResponseHandler(status, response)
    {

        if(response.error)
        {
            $("#charge-error").removeClass("hidden");
            $("#charge-error").html(response.error.message);
            $("#checkout-button").prop("disabled", false);
        }
        else
        {
            var token = response.id;
            $form.append($("<input type='hidden' name='stripeToken'>").val(token));
            $form.get(0).submit();
        }

    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>